﻿app.controller('homeController', function ($http, $scope, $window) {
});